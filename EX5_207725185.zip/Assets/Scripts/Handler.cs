using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class Handler : MonoBehaviour
{
    public Animator windowController;
    public GameObject startPanel;
   public void OnClick()
    {
        Debug.Log(Time.time);
    }

    // Shows or hides pause window based on the provided boolean value.
    public void ShowWindow(bool value)
    {
        Time.timeScale = value ? 0f : 1f;
        windowController.SetBool("show", value);
    }

    // Hides the start panel and initiates the fruit shooting process.
    public void HideStart()
    {
        startPanel.SetActive(false);
        FruitShooter.StartShoot();

    }
}
