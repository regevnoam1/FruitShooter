using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Game : MonoBehaviour
{
    public static Game instance;
    public GameObject gameOverPanel;

    private void Awake()
    {
        if (instance != null)
        {
            Debug.LogError("Singleton violation!");
            return;
        }
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        // Make sure the gameOverPanel is initially inactive
        if (gameOverPanel != null)
        {
            gameOverPanel.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    // Method to handle the Game Over sequence
    public static void GameOver()
    {
        if (instance.gameOverPanel != null)
        {
            FruitShooter.StopShoot();
            instance.gameOverPanel.SetActive(true);
            Debug.Log("Game Over!");
        }
    }

}
