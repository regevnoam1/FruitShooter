using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitHanfler : MonoBehaviour
{
    public GameObject startMenu;
    public GameObject gameOverMenu;

    public Shoot shooter;
    public Destroyer destroyer;
    // Start is called before the first frame update
    public void ExitGame()
    {
        gameOverMenu.SetActive(false);
        startMenu.SetActive(true);
        shooter.ResetHighscore();
        shooter.ResetScore();
        destroyer.ResetLives();
        FruitShooter.StopShoot();
    }

    public void ExitResetButton()
    {
        shooter.ResetScore();
        destroyer.ResetLives();
        gameOverMenu.SetActive(false);
        FruitShooter.StartShoot();
    }
}
