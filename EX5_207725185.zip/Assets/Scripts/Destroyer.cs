using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Destroyer : MonoBehaviour
{
    public TextMeshProUGUI livesText;
    private int _lives = 5;
    void OnTriggerEnter(Collider collider)
    {
        if (!collider.gameObject.CompareTag("Bomb"))
        {

            _lives--;
            livesText.text = "Lives:" + _lives;
            if (_lives == 0)
            {
                Game.GameOver();
            }
            Destroy(collider.gameObject);
        }
        else
        {
            Destroy(collider.gameObject);
        }
    }
    public void ResetLives()
    {
        _lives = 5;
        livesText.text = "Lives:" + _lives;
    }
}
