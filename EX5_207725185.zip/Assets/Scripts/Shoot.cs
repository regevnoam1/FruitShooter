using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Shoot : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    private int _score;
    private int _highscore = 0;
    public Camera cam;
    private AudioSource _audioSource;
    public TextMeshProUGUI highscoreText;
    public TextMeshProUGUI endscoreText;
    public GameObject newHighscoreText;
    // Start is called before the first frame update
    void Start()
    {
        _audioSource = gameObject.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Fire();
        }
    }
    void Fire()
    {
        print("Pachau Phachhu");
        _audioSource.Play();
        RaycastHit hit = new RaycastHit();
        Ray ray = cam.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit,1000.0f)) {
            // Check if the hit object is a bomb, and trigger game over if true.
            if (hit.collider.gameObject.CompareTag("Bomb"))
            {
                Invoke("GameOverWithDelay", 0.5f);
                return;
            }

            // Check if the hit object has an Item component, and handle the explosion.
            Item item = hit.rigidbody.gameObject.GetComponent<Item>();
            if (item)
            {
                item.Explode();
                _score++;
                scoreText.text = "Score:" + _score;
                endscoreText.text = "Your Score:" + _score;
                if (_score >= _highscore)
                {
                    _highscore = _score;
                    highscoreText.text = "Highscore:" + _highscore;
                    newHighscoreText.SetActive(true);
                }
            }
            Debug.Log(Time.time+"HIT!!!! "+hit.collider.gameObject.name);

        }
    }
    // Method to call Game.GameOver() with a delay
    void GameOverWithDelay()
    {
        Game.GameOver();
    }
    public void ResetScore()
    {
        newHighscoreText.SetActive(false);
        _score = 0;
        scoreText.text = "Score:" + _score;
        endscoreText.text = "Your Score:" + _score;

    }

    public void ResetHighscore()
    {
        _highscore = 0;
        highscoreText.text = "Highscore:" + _highscore;
    }
}
