using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitShooter : MonoBehaviour
{
    public GameObject[] prefabs;
    public float minForce;
    public float maxForce;

    private float _minTime = 1;
    private float _maxTime = 3;

    private float _minAngle = -60;
    private float _maxAngle = 60;

    public static bool canShoot = false;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(ThrowLoop());
    }

    IEnumerator ThrowLoop()
    {
        while (true)
        {
            yield return new WaitForSeconds(Random.Range(_minTime, _maxTime));
            if (canShoot)
            {
                ThrowAFruit();
            }
        }
    }
    public void ThrowAFruit()
    {
        GameObject selectedPrefab;
        if (Random.value < 0.2f)
        {
            //Bomb prefab located as the last one.
           selectedPrefab = prefabs[prefabs.Length - 1];
        }
        else
        {
            //Regular Fruit will choose randomly.
            selectedPrefab = prefabs[Random.Range(0, prefabs.Length-1)];
        }
        transform.parent.localEulerAngles = new Vector3 (0, 0, Random.Range(_minAngle, _maxAngle));
        GameObject go = (GameObject)Instantiate(selectedPrefab, transform.position, Quaternion.identity);
        go.GetComponent<Rigidbody>().AddForce(transform.forward * Random.Range(minForce, maxForce));
        go.GetComponent<Rigidbody>().AddTorque(new Vector3(Random.Range(_minAngle, _maxAngle), Random.Range(_minAngle, _maxAngle), 0));
    }
    public static void StartShoot()
    {
        canShoot=true;
      
    }
    public static void StopShoot()
    {
        canShoot = false;
    }
}
